import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'Malgun Gothic'